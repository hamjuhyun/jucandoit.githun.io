# DOM 
### D는 (document) document object model 에서 document 가 없으면 움직이지 않습니다.
### 웹 문서를 만들어 웹 브라우저를 띄우는 순간 DOM 은 살아 움직입니다.

### O는 객체입니다 지난주에 알려드렸던 내용들중 객체 사용법에 대해 알려드린거 기억날거에요
### 객체를 포함한 변수?들을 프로퍼티라고 하고 객체를 실행하는 함수를 메소드라고 했던거 기억나실겁니다.
### 자바스크립트에 세종류의 객체가 있습니다.
1. 프로그래머가 만든 객체
2. 배열 수학 날짜와 같이 자바스크립트에 이미 만들어진 객체
3. 웹 브라우저가 제공하는 객체
### 그중 가장 기본이 window object 입니다  머 여러분이 잘아는 window.open 등등이 있습니다.
### 우리는 이 과정은 생략하도록 하겠습니다.

### M model 은 모형을 말합니다. 그런데 모형이라는 단어보단 지도라고 이해하는게 더 쉬울거 같네요
### 지도는 흔히 등고선이나 방향 축적같은 규칙이 있습니다.
### 모델에서도 지도처럼 정보를 얻으려면 규칙들이 있습니다 dom 에서 사용 하는 가장 중요한 규칙 중 하나인 tree 형 구조로 표시한다는 겁니다. (dom tree 이미지는 구글에서 확)


## getElementById
### 이름만 봐도 무슨 역활인지 대충 감이 올것입니다. 
### 이를 통해 특정아이디의 dom 에 접근이 가능해집니다.
### 여기서 주의할점 대소문자를 구별해서 써야될것

```javascript
    document.getElementById('id'); //홀따옴표도 가능
    document.getElementById("id"); //쌍따옴표도 가능
    //실제로 되는지 같이 해보자
```

## getElementsByTagName
### getElementsByTagName 를 사용하면 특정 태그를 사용하는 요소들을 배열로 얻어낼수있습니다.
```javascript
    document.getElementsByTagName('li');
    document.getElementsByTagName('li').length;// 이렇게 배열의 길이도 확인할수있다
    //실제로 되는지 같이 해보자 그리고 for 문같은걸 이용해서 구조분해도 할수있
```

# 속성 다루기

## getAttribute 
### getAttribute 도 함수입니다 그리고 인수를 하나 같습니다 바로 속성명이죠
### 가령 p 태그에서 title 속성을 얻는 다고 가정해보겠습니다.
```javascript
    var p = document.getElementsByClassName('p');
    for(var i = 0; i<p.length; i++ ){
        console.log(p[i].getAttribute('title'));
    }
    //이것도 다양한 예제로 같이해보자
```

## setAttribute
### 지금까지는 우리는 항상 get 메소드를 통해서 가지고 오는것만해보았습니다.
### 이번에는 조금 다른 성격인 메소드를 사용해볼텐데요 setAttribute 를 통해서 속성 값을 바꿔 보도록 하겠습니다.

```javascript
    var a = document.getElementById('a');
    a.setAttribute('href', 'http://www.naver.com');
    //이걸 가지고 다영한 예제를 같이해보자
```



