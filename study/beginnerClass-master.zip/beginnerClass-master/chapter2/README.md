# 조건문 
## 웹 브라우저가 스크립트 코드를 해석할때 각 구문을 순서대로 실행한다 더많은 구문을 실행하기전에 가장 많이쓰는 조건문이 if문인데 다음과 같이 동작한다
```javascript
    if(조건){
        명령문;
    }
```
### 괄호안에 들어가는 조건은 항상 참과 거짓 중 하나인 불린 값을 갖게 된다
```javascript
 if(1 > 2) {
    alert('토요일 오전 공부하기 싫타');
 } 
```
### 1은 2보다 작기떄문에 절대 alert창이 나올수가 없다.
### 중괄호 생략이 가능하다
```javascript
   if(1 > 2) alert('토요일 오전 공부하기 싫타');
```

### if문은 else문을 통해 확장할수있다 else문을쓰면 거짓일떄 실핼할수있는 문장도 지정할수있다
```javascript
   if(1 > 2){
    alert('토요일 오전 공부하기 싫타'); 
   }else {
    alert('그래도 열심히 공부를 해야지');
   }
```

# 비교연산자
## 자바스크립트에서는 거의 대부분의 조건문을 수행할수있는 풍부한 연사자를 사용할수 있다.
## 크기를 비교하기 위해 >크다 <작다 >=크거나같다 <=작거나같다같은 것이다
## 두개의 값이 같은지 비교할때는 == 등호를 사용한다
```javascript
   var my_mood = '행복';
   var your_mood = '슬픔';
   if(my_mood = your_mood){
       alert('우리둘다 같은 느낌이네유~');
   }
```
### 이것은 my_mood에게 your_mood를 할당해주는것을 성공했기때문에 조건이 참이 되므로 alert창이 뜬다.
### 정확한 방법은 아래와 같다.
```javascript
   var my_mood = '행복';
   var your_mood = '슬픔';
   if(my_mood == your_mood){
       alert('우리둘다 같은 느낌이네유~');
   }
```
### 두값을 비교하는 연산자는 또 있다 !=같지 않다라는 연산자를 수행하게 된다
```javascript
    var my_mood = '행복';
    var your_mood = '슬픔';
    if(my_mood != your_mood){
       alert('우리둘다 같은 느낌이네유~');
    }
``` 

# 논리연산자
## 조건문의 여러 연산 조건을 합치는것이 가능하다 즉 num이라 불리는 값이 5에서 10사이에 있어야 된다 하는 조건문을 찾아본다고 생각해보자
## 먼저 값이 5보다 크거나 같아야되고 10보다는 작거나 같아야됩니다.
```javascript\
    if(num >=5 && num <=10){
       alert('num이 올바른 범위안에 있습니다');
    }
``` 
### 위에 && 앤퍼센트를 사용한 논리곱(and)를 논리 연산자라고 부름
### and연산자는 두 조건이 참일때만 실행된다
### 논리의합(or)연산자는 두개의 파이프 ||를 사용합니다.
### 두조건중 하나만 참이라도 실행된다 물론 둘다 참이라도 실행된다

```javascript\
    if(num >10 || num <5){
       alert('올바른 범위를 벗어났습니다');
    }
```

# while문
## 형태는 if문과 매우 유사
## 다른점이 있다면 {}안에서 문장 실행이 반복된다

```javascript\
    var count = 1;
    while(count < 11){
        console.log(count);
        count++;
    }
```

### 위 코드를 자세히 보겠다
### 다른점이라고 하면 중괄호 안에 코드가 계속 반복 실행된다는것이다.


# do... while문
## if문과 마찬가지로 while문은 중괄호 코드안에 코드가 한번도 실행되지 않을수가 있다
## 조건이 거짓일때 한번은 실행해야 할떄가 있다 그럴때 사용한다.

```javascript\
    var count = 1;
    do {
        console.log(1)
    }while(count < 0)
    
    
    var count = 1;
    do {
        console.log(1)
        count++
    }while(count < 10)

```

# for문
## while문과 비슷하다고 생각하면된다 

```javascript\
    //while문
    while(조건){
    
    }
    
    //for문
    for(초기조건; 조건식; 조건변경){
        명령문;
    }

```

### 앞서 만든 do문을 for문으로 변경해보자

```javascript\
    for(var count = 1; count < 11; count++){
        console.log(count);
    }
    
    var studyMemeber = ['ivan', '계혁진', '김종덕', '함주', 'Ssun'];
    
    for(var i = 0; i < studyMemeber.length; i++){
        console.log(studyMember[i]);
    }
```

# 함수
## 어떤기능을 가진 코드를 한번이상 계속 사용하고 싶다면 그런 코드를 묶어서 함수라고 지정할수있습니다.
## 즉 어디서나 불러 재사용이 가능한 명령어 묶음이라고 보심된다

```javascript\
    function shout(){
        for(var i = 0; i < studyMemeber.length; i++){
            console.log(studyMember[i]);
        }
    }
    
    shout();

```

### 이렇게 하다보면 한번이상 실행해야하는 코드들을 여러번 작성할 필요가 없어진다
### 함수안에 특정데이터를 넣을수 있게 되는데 이것을 인수(argument)라고 부른다
```javascript\
    function shout(인수){
        명령문;
    }
```

### 이쯤되면 눈치가 있는분들은 캐취했을것이다 자바스크립트 내에는 이미 만들어져있는 함수가 많다 이미 사용해보신 alert()함수이다
### 인수는 멀티로도 받을수 있고 함수내에서 처리가능하다.
### 인수 두개를 받아서 합 한 값을 리턴하는 더하기(add)함수를 만들어보자




