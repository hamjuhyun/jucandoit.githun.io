#자바스크립트 기본타입
자바스크립트의 기본타입은 숫자, 문자열, 불린값을 비롯한 null, undefined가 있다.  
이타입의 특징은 하나의 값을 나타낸다는것이다 예제를 통해 기본 타입에 대해서 간단히 살펴보자

```javascript
    //숫자 타입
    var intNum = 10;
    var floatNum = 0.1;
    
    //문자 타입
    var singleQuoteStr = 'singleQuoteStr';
    var dobuleQuoteStr = "dobuleQuoteStr";
    var singleChar = 'a';
    
    //블린타입
    var boolVar = true;
    
    //undefined타입
    var emptyVar;
    
    //null타입
    var nullVar = null;
    
    console.log(
        typeof intNum,
        typeof floatNum,
        typeof singleQuoteStr,
        typeof dobuleQuoteStr,
        typeof singleChar,
        typeof boolVar,
        typeof emptyVar,
        typeof nullVar
        )
```

#자바스크립트 참조 타입
자바스크립에서 숫자 문자열, 불린값 null, nudefined같은 기본 타입을 제외한 모든 값은 객체다
따라서 배열 함수 정규 표현식 등도 모두 객체로 표현된다

##Object()생성자 함수를 이용한 객체 생성

```javascript

    //Object()를 이용해서 foo 빈 객체 생성
    var foo  =  new Object();

    //foo객체 프로퍼티 생성
    foo.name = 'foo';
    foo.age = 30;
    foo.gender = 'male'
    
    console.log(typeof foo);
    console.log(foo);
```

##객체 리터럴 방식을 이용한 객체 생성
```javascript
    var foo = {
        name : 'foo',
        age : 30,
        gender : 'male' 
    }
    
    console.log(typeof foo);
    console.log(foo);
    
```

##객체 프로퍼티 읽기/쓰기/업데이트
객체의 프로퍼티에 접근하려면 두가지 방법을 사용한다  
* 대괄호 [] 표기법  
* 마침표 . 표기법

```javascript
var foo = {
    name : 'foo',
    major : 'computer science'
}

//객체 프로퍼티 읽기
console.log(foo.name);
console.log(foo[name]);
console.log(foo.nickName);


//객체 프로퍼티 갱신
foo.major = 'electronics engineering';
console.log(foo.major);
console.log(foo[major]);

//동적 프로퍼티 생성
foo.age = 30;
console.log(foo.age);
```

#객체 비교
##기본타입과 참조타입 비교
```javascript
var a = 10;
var b = 10;
var c = 'aa';
var d = 'aa';
console.log(a == b);
console.log(c == d);

var k = {
    value : 10
}

var j = {
    value : 10
}

console.log(k == j)

var t = k;

console.log(k == t);
console.log(k === t);


```

